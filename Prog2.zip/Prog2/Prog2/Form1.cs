﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            bool errors = false;

            int noOfGuests = 0;
            int noOfNights = 0;
            int hotelStars = 0;

            double guestPrice = 0;
            double nightPrice = 0;
            double multiplier = 0;
            double hotelCost = 0;


            // check if no of guests is a number
            if (int.TryParse(noOfGuestsTextBox.Text, out noOfGuests))
            {
                if (noOfGuests == 1)
                {
                    guestPrice = 100;
                }

                else if (noOfGuests == 2)
                {
                    guestPrice = 150;
                }

                else if (noOfGuests == 3)
                {
                    guestPrice = 250;
                }

                else if (noOfGuests <= 7)
                {
                    guestPrice = 400;
                }
                else
                {
                    MessageBox.Show("Number of guests must be int the range of 1 - 7");
                    noOfGuestsTextBox.Focus();
                    errors = true;
                }
            }
            else
            {
                MessageBox.Show("Number of guests must be a number");
                noOfGuestsTextBox.Focus();
                errors = true;
            }

            // check if no of nights is a number
            if (int.TryParse(noOfNightsTextBox.Text, out noOfNights))
            {
                if (noOfNights < 7)
                {
                    nightPrice = 100;
                }

                else if (noOfNights < 31)
                {
                    nightPrice = 75;
                }

                else
                {
                    nightPrice = 25;
                }
            }
            else
            {
                MessageBox.Show("Numeber of guests must be a number");
                noOfGuestsTextBox.Focus();
                errors = true;
            }

            if (hotelStarsComboBox.SelectedIndex > -1)
            {
                hotelStars = Convert.ToInt32(hotelStarsComboBox.SelectedItem);

                if (hotelStars == 1)
                {
                    multiplier = 1;
                }

                else if (hotelStars == 2)
                {
                    multiplier = 1.5;
                }

                else if (hotelStars == 3)
                {
                    multiplier = 2.5;
                }

                else if (hotelStars == 4)
                {
                    multiplier = 3;
                }

                else if (hotelStars == 5)
                {
                    multiplier = 4;
                }
            }

            else
            {
                MessageBox.Show("You must select hotel stars");
                hotelStarsComboBox.Focus();
                errors = true;
            }

            // perform calculation if all the fields have been filled correctly
            if (!errors)
            {
                hotelCost = (guestPrice + (nightPrice * noOfNights)) * multiplier;

                hotelCostTextBox.Text = String.Format("{0:C}", hotelCost);
            }
        }
    }
}